<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'posconnect');

/** MySQL database username */
define('DB_USER', 'posconnect');

/** MySQL database password */
define('DB_PASSWORD', 'abcdefg');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('WP_ALLOW_MULTISITE', true);

define('MULTISITE', true);
define('SUBDOMAIN_INSTALL', false);
$base = '/';
define('DOMAIN_CURRENT_SITE', 'localhost');
define('PATH_CURRENT_SITE', '/');
define('SITE_ID_CURRENT_SITE', 1);
define('BLOG_ID_CURRENT_SITE', 1);

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '@Kyw{79*tI^;[smH^.&M>59-6>:4)[;T2H9ds$Rt,:QdJICwg;JT6&$KBy3OBky.');
define('SECURE_AUTH_KEY',  'c<{H@:%2x2kw|0uR(!7W0PP{>unBAu6.&45jX>KQ/4Tb((QQ5?SN!gfcnzffgqs0');
define('LOGGED_IN_KEY',    'A}~cmpcpbTj}<(+YJ?M%(=+M$s_B5:`iq0=o2#OG$A@]).R!;_/$F*)]U]TzKU2h');
define('NONCE_KEY',        'YO1t5^8efyp8y5Gl{S%,gp@/r5Ar3s}L/kudYyCoJZdSi,jLi@<#F_s&vdI !oO!');
define('AUTH_SALT',        '?0wYh5@RL&o lZJn1b2>U1sh9gy=cR_%b^%p0(vL nRI_8Wc(LNJw3AW>Pr@w_K)');
define('SECURE_AUTH_SALT', 'FazfjaL0^5JgfUYO%4pXR{&=dk3QAC6VJz*3ocS)s~{XWi3BIb%=Sx5~pkR>FqU)');
define('LOGGED_IN_SALT',   'sgFz7@rqtW4Z;<`(aPZkx -|DM_j(LB,fX9IMww4>8xhchEz*i^Q%2@PKB5I2`Tm');
define('NONCE_SALT',       'l}{Svp&?LPQB5#z? ?L+!l#qx~kgvH=HS(xddgU]GD/_[ryoZrqET=:QZKjAY_Bc');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
