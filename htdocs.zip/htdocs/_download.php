<?php
mysql_connect("localhost", "posconnect", "abcdefg") or die(mysql_error());
mysql_select_db("posconnect") or die(mysql_error());

$author = 1;
$site_index = 5;
$category_link = 'http://localhost/store1/uncategorized/';
$post_type = 'wpsc-product';
$default_product_metadata = 'a:20:{s:24:"unpublish_when_none_left";s:1:"1";s:25:"wpec_taxes_taxable_amount";s:0:"";s:13:"external_link";s:0:"";s:18:"external_link_text";s:0:"";s:20:"external_link_target";s:0:"";s:11:"no_shipping";s:1:"0";s:6:"weight";s:1:"0";s:11:"weight_unit";s:5:"pound";s:10:"dimensions";a:6:{s:6:"height";s:1:"0";s:11:"height_unit";s:2:"in";s:5:"width";s:1:"0";s:10:"width_unit";s:2:"in";s:6:"length";s:1:"0";s:11:"length_unit";s:2:"in";}s:8:"shipping";a:2:{s:5:"local";s:1:"0";s:13:"international";s:1:"0";}s:14:"merchant_notes";s:0:"";s:8:"engraved";s:1:"0";s:23:"can_have_uploaded_image";s:1:"0";s:15:"enable_comments";s:0:"";s:21:"notify_when_none_left";s:1:"0";s:16:"quantity_limited";s:1:"0";s:7:"special";s:1:"0";s:17:"display_weight_as";s:5:"pound";s:16:"table_rate_price";a:2:{s:8:"quantity";a:0:{}s:11:"table_price";a:0:{}}s:17:"google_prohibited";s:1:"0";}';

$productA = Array("59 Minute Baseball Practice DVD.", "59 Minute Baseball Practice", "59-minute-baseball-practice", 89.98, 46);
$productB = Array("Adult baseball glove.", "Adult Baseball Glove", "adult-baseball-glove", 29.95, 1);
$productC = Array("Classic fit baseball hat.", "Baseball Hat", "baseball-hat", 11.99, 6);
$productD = Array("Hard top ball bucket.", "Ball Bucket - hard top", "ball-bucket-hard-top", 89.98, 106);
$productE = Array("Soft pack ball bucket.", "Ball Bucket - soft pack", "ball-bucket-soft-pack", 15.95, 106);
$products = Array($productA, $productB, $productC, $productD, $productE);

foreach($products as $product) {
  print_r($product);
  $query = sprintf("INSERT INTO wp_%d_posts VALUES(null, 1, now(), now(), '%s', '%s', '', 'publish', 'closed', 'closed', '', '%s', '', '', now(), now(), '', 0, '%s', 0, '%s', '', 0)", $site_index, mysql_real_escape_string($product[0]), mysql_real_escape_string($product[1]), mysql_real_escape_string($product[2]), mysql_real_escape_string($category_link), $post_type);
  $result = mysql_query($query);
  if(!$result) die(mysql_error());
  $post_id = mysql_insert_id();
  $metas = Array();
  $metas[0] = Array("_wpsc_product_metadata", $default_product_metadata);
  $metas[1] = Array("_wpsc_currency", "a:0:{}");
  $metas[2] = Array("_wpsc_is_donation", "0");
  $metas[3] = Array("_wpsc_sku", "");
  $metas[4] = Array("_wpsc_price", $product[3]);
  $metas[5] = Array("_wpsc_stock", $product[4]);
  foreach($metas as $meta) {
    $query = sprintf("INSERT INTO wp_%d_postmeta VALUES(null, $post_id, '%s', '%s')", $site_index, $meta[0], $meta[1]);
    $result = mysql_query($query);
    if(!$result) die(mysql_error());
  }
}

header("Location: /POS_Setup.msi")
?>
